# 添加与修改的代码列表

ptdump.h

* 说明：复制arch/arm64/include/asm/ptdump.h 的内容并按照实验指导进行修改



Makefile

* 说明：按照实验指导修改，使得CONFIG\_RISCV\_PGDUMP为y时ptdump_debugfs.o和dump.o在make时变编译进内核中



pgtable-64.h

* 说明：按照实验指导修改，定义不同level时的数据结构



Kconfig.debug

* 说明：使得CONFIG\_RISCV\_PGDUMP默认配置为y



ptdump_debugfs.c

* 说明：按照实验指导直接复制arch/arm64/mm/ptdump_debugfs.c 内容



dump.c

* 说明：复制arch/arm64/mm/dump.c,并对其做简单修改

具体修改位置如下表所示：

### 原有文件改写：

| 目的                                                         | 改写位置                                             |
| ------------------------------------------------------------ | ---------------------------------------------------- |
| 修改头文件                                                   | Ln 34 ~ Ln 43                                        |
| 定义VA_START (内核虚拟地址空间起始地址)                      | Ln 46 ~ Ln 49                                        |
| 定义 riscv 内核地址布局                                      | Ln 51 ~ Ln 74                                        |
| 添加对 pmd_sect 和 pud_sect 的宏定义                         | Ln 89 ~ Ln 95                                        |
| 修改 struct pg_state                                         | Ln 98 ~ Ln 122                                       |
| 定义 page table entry 的低位                                 | Ln 131 & Ln 231                                      |
| 删除函数 note_prot_uxn, note_prot_wx，ptdump_check_wx 的定义以及调用 | Ln 279 ~ Ln 307  & Ln 325 ~ Ln 326 & Ln 459 ~ Ln 477 |
| 修改 walk_pgd 函数中第一行为 unsigned long end = 0;          | Ln 413 ~ Ln 414                                      |



　







