// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (c) 2014, The Linux Foundation. All rights reserved.
 * Debug helper to dump the current kernel pagetables of the system
 * so that we can see what the various memory ranges are set to.
 *
 * Derived from x86 and arm implementation:
 * (C) Copyright 2008 Intel Corporation
 *
 * Author: Arjan van de Ven <arjan@linux.intel.com>
 */

/*--old head--*/
/*

#include <linux/debugfs.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/io.h>
#include <linux/init.h>
#include <linux/mm.h>
#include <linux/sched.h>
#include <linux/seq_file.h>

#include <asm/fixmap.h>
#include <asm/kasan.h>
#include <asm/memory.h>
#include <asm/pgtable.h>
#include <asm/pgtable-hwdef.h>
#include <asm/ptdump.h>

*/

/*--new head--*/
#include <asm/page.h>
#include <asm/pgtable-bits.h>
#include <asm/pgtable-64.h>
#include <asm/pgtable.h>
#include <asm/ptdump.h>

#include <linux/types.h>
#include <linux/kernel.h>
#include <linux/sizes.h>


/* define VA_START */
#define VA_BITS 39
#define VA_START		(UL(0xffffffffffffffff) - \
	(UL(1) << VA_BITS) + 1)

#define FIXADDR_MID (FIXADDR_START+UL(0x10000))

static const struct addr_marker address_markers[] = {
#ifdef CONFIG_KASAN
	{ KASAN_SHADOW_START,	"Kasan shadow start" },
	{ KASAN_SHADOW_END,		"Kasan shadow end" },
#endif
	//{ MODULES_VADDR,		"Modules start" },
	//{ MODULES_END,		"Modules end" },
	{ FIXADDR_START,		"unknow start"},
	{ FIXADDR_MID,			"unknow end"},
	{ FIXADDR_MID,			"Fixmap start" },
	{ FIXADDR_TOP,			"Fixmap end" },
	{ VMALLOC_START,        "vmalloc() area" },
	{ VMALLOC_END,          "vmalloc() end" },
	//{ PCI_IO_START,		"PCI I/O start" },
	//{ PCI_IO_END,			"PCI I/O end" },
#ifdef CONFIG_SPARSEMEM_VMEMMAP
	{ VMEMMAP_START,		"vmemmap start" },
	{ VMEMMAP_START + VMEMMAP_SIZE,	"vmemmap end" },
#endif
	{ PAGE_OFFSET,			"Linear mapping" },
	{ -1,				NULL },
};

#define pt_dump_seq_printf(m, fmt, args...)	\
({						\
	if (m)					\
		seq_printf(m, fmt, ##args);	\
})

#define pt_dump_seq_puts(m, fmt)	\
({					\
	if (m)				\
		seq_printf(m, fmt);	\
})


#define SECT_MASK (UL(0xfffffffffffffff1))

#define pud_sect(pud)		(!((pud_val(pud) & SECT_MASK) == \
						 pud_val(pud)))

#define pmd_sect(pmd)		(!((pmd_val(pmd) & SECT_MASK) == \
						 pmd_val(pmd)))


/*
 * The page dumper groups page table entries of the same type into a single
 * description. It uses pg_state to track the range information while
 * iterating over the pte entries. When the continuity is broken it then
 * dumps out a description of the range.
 */
/*struct pg_state {
	struct seq_file *seq;
	const struct addr_marker *marker;
	unsigned long start_address;
	unsigned level;
	u64 current_prot;
	bool check_wx;
	unsigned long wx_pages;
	unsigned long uxn_pages;
};*/

/*--modified pg_state--*/
struct pg_state {
        struct seq_file *seq;
        const struct addr_marker *marker;
        unsigned long start_address;
        unsigned level;
        u64 current_prot;
};

struct prot_bits {
	u64		mask;
	u64		val;
	const char	*set;
	const char	*clear;
};

/*---- modified by Percy ----*/
/*
---------------------------------------------------------
|                      | 7 | 6 | 5 | 4 | 3 | 2 | 1 | 0 |
|                      | D | A | G | U | X | W | R | V |
---------------------------------------------------------
*/

#define PTE_VALID		(_AT(pteval_t, 1) << 0) 
#define PTE_RD			(_AT(pteval_t, 1) << 1) 
#define PTE_WR			(_AT(pteval_t, 1) << 2)
#define PTE_EX                  (_AT(pteval_t, 1) << 3)
#define PTE_USER		(_AT(pteval_t, 1) << 4)  
#define PTE_GLOBAL		(_AT(pteval_t, 1) << 5) 
#define PTE_AF			(_AT(pteval_t, 1) << 6)
#define PTE_DBM			(_AT(pteval_t, 1) << 7)	 

static const struct prot_bits pte_bits[] = {
	{
		.mask	= PTE_VALID,
		.val	= PTE_VALID,
		.set	= "V",
		.clear	= "F",
	}, {
		.mask	= PTE_RD,
		.val	= PTE_RD,
		.set	= "R",
		.clear	= " ",
	}, {
		.mask	= PTE_WR,
		.val	= PTE_WR,
		.set	= "W",
		.clear	= " ",
	}, { 
		.mask	= PTE_EX,
		.val	= PTE_EX,
		.set	= "x ",
		.clear	= "Nx",
	}, {
		.mask   = PTE_USER,
		.val    = PTE_USER,
		.set    = "U",
		.clear  = "S"	 
	}, {
		.mask	= PTE_GLOBAL,
		.val	= PTE_GLOBAL,
		.set	= "GLO",
		.clear	= "   ",
	}, {
		.mask	= PTE_AF,
		.val	= PTE_AF,
		.set	= "A ",
		.clear	= " ",
	}, {
		.mask	= PTE_DBM,
		.val	= PTE_DBM,
		.set	= "D",
		.clear	= " ",
	},
	// {
	// 	.mask	= PTE_NG,
	// 	.val	= PTE_NG,
	// 	.set	= "NG",
	// 	.clear	= "  ",
	// }
	// , {
	// 	.mask	= PTE_CONT,
	// 	.val	= PTE_CONT,
	// 	.set	= "CON",
	// 	.clear	= "   ",
	// }, {
	// 	.mask	= PTE_TABLE_BIT,
	// 	.val	= PTE_TABLE_BIT,
	// 	.set	= "   ",
	// 	.clear	= "BLK",
	// }, {
	// 	.mask	= PTE_UXN,
	// 	.val	= PTE_UXN,
	// 	.set	= "UXN",
	// }, {
	// 	.mask	= PTE_ATTRINDX_MASK,
	// 	.val	= PTE_ATTRINDX(MT_DEVICE_nGnRnE),
	// 	.set	= "DEVICE/nGnRnE",
	// }, {
	// 	.mask	= PTE_ATTRINDX_MASK,
	// 	.val	= PTE_ATTRINDX(MT_DEVICE_nGnRE),
	// 	.set	= "DEVICE/nGnRE",
	// }, {
	// 	.mask	= PTE_ATTRINDX_MASK,
	// 	.val	= PTE_ATTRINDX(MT_DEVICE_GRE),
	// 	.set	= "DEVICE/GRE",
	// }, {
	// 	.mask	= PTE_ATTRINDX_MASK,
	// 	.val	= PTE_ATTRINDX(MT_NORMAL_NC),
	// 	.set	= "MEM/NORMAL-NC",
	// }, {
	// 	.mask	= PTE_ATTRINDX_MASK,
	// 	.val	= PTE_ATTRINDX(MT_NORMAL),
	// 	.set	= "MEM/NORMAL",
	// }
};

struct pg_level {
	const struct prot_bits *bits;
	const char *name;
	size_t num;
	u64 mask;
};

static struct pg_level pg_level[] = {
	{
	}, { /* pgd */
		.name	= "PGD",
		.bits	= pte_bits,
		.num	= ARRAY_SIZE(pte_bits),
	}, { /* pud */
		.name	= (CONFIG_PGTABLE_LEVELS > 3) ? "PUD" : "PGD",
		.bits	= pte_bits,
		.num	= ARRAY_SIZE(pte_bits),
	}, { /* pmd */
		.name	= (CONFIG_PGTABLE_LEVELS > 2) ? "PMD" : "PGD",
		.bits	= pte_bits,
		.num	= ARRAY_SIZE(pte_bits),
	}, { /* pte */
		.name	= "PTE",
		.bits	= pte_bits,
		.num	= ARRAY_SIZE(pte_bits),
	},
};

static void dump_prot(struct pg_state *st, const struct prot_bits *bits,
			size_t num)
{
	unsigned i;

	for (i = 0; i < num; i++, bits++) {
		const char *s;

		if ((st->current_prot & bits->mask) == bits->val)
			s = bits->set;
		else
			s = bits->clear;

		if (s)
			pt_dump_seq_printf(st->seq, " %s", s);
	}
}

/*static void note_prot_uxn(struct pg_state *st, unsigned long addr)
{
	if (!st->check_wx)
		return;

	if ((st->current_prot & PTE_UXN) == PTE_UXN)
		return;

	WARN_ONCE(1, "arm64/mm: Found non-UXN mapping at address %p/%pS\n",
		  (void *)st->start_address, (void *)st->start_address);

	st->uxn_pages += (addr - st->start_address) / PAGE_SIZE;
}

static void note_prot_wx(struct pg_state *st, unsigned long addr)
{
	if (!st->check_wx)
		return;
	if ((st->current_prot & PTE_RDONLY) == PTE_RDONLY)
		return;
	if ((st->current_prot & PTE_PXN) == PTE_PXN)
		return;

	WARN_ONCE(1, "arm64/mm: Found insecure W+X mapping at address %p/%pS\n",
		  (void *)st->start_address, (void *)st->start_address);

	st->wx_pages += (addr - st->start_address) / PAGE_SIZE;
}
*/
static void note_page(struct pg_state *st, unsigned long addr, unsigned level,
				u64 val)
{
	static const char units[] = "KMGTPE";
	u64 prot = val & pg_level[level].mask;

	if (!st->level) {
		st->level = level;
		st->current_prot = prot;
		st->start_address = addr;
		pt_dump_seq_printf(st->seq, "---[ %s ]---\n", st->marker->name);
	} else if (prot != st->current_prot || level != st->level ||
		   addr >= st->marker[1].start_address) {
		const char *unit = units;
		unsigned long delta;

		if (st->current_prot) {
			//note_prot_uxn(st, addr);
			//note_prot_wx(st, addr);
			pt_dump_seq_printf(st->seq, "0x%016lx-0x%016lx   ",
				   st->start_address, addr);

			delta = (addr - st->start_address) >> 10;
			while (!(delta & 1023) && unit[1]) {
				delta >>= 10;
				unit++;
			}
			pt_dump_seq_printf(st->seq, "%9lu%c %s", delta, *unit,
				   pg_level[st->level].name);

			if (pg_level[st->level].bits)
				dump_prot(st, pg_level[st->level].bits,
					  pg_level[st->level].num);
			pt_dump_seq_puts(st->seq, "\n");
		}

		if (addr >= st->marker[1].start_address) {
			st->marker++;
			pt_dump_seq_printf(st->seq, "---[ %s ]---\n", st->marker->name);
		}

		st->start_address = addr;
		st->current_prot = prot;
		st->level = level;
	}

	if (addr >= st->marker[1].start_address) {
		st->marker++;
		pt_dump_seq_printf(st->seq, "---[ %s ]---\n", st->marker->name);
	}

}

static void walk_pte(struct pg_state *st, pmd_t *pmdp, unsigned long start,
		     unsigned long end)
{
	unsigned long addr = start;
	pte_t *ptep = pte_offset_kernel(pmdp, start);

	do {
		note_page(st, addr, 4, READ_ONCE(pte_val(*ptep)));
	} while (ptep++, addr += PAGE_SIZE, addr != end);
}

static void walk_pmd(struct pg_state *st, pud_t *pudp, unsigned long start,
		     unsigned long end)
{
	unsigned long next, addr = start;
	pmd_t *pmdp = pmd_offset(pudp, start);

	do {
		pmd_t pmd = READ_ONCE(*pmdp);
		next = pmd_addr_end(addr, end);

		if (pmd_none(pmd) || pmd_sect(pmd)) {
			note_page(st, addr, 3, pmd_val(pmd));
		} else {
			BUG_ON(pmd_bad(pmd));
			walk_pte(st, pmdp, addr, next);
		}
	} while (pmdp++, addr = next, addr != end);
}

static void walk_pud(struct pg_state *st, pgd_t *pgdp, unsigned long start,
		     unsigned long end)
{
	unsigned long next, addr = start;
	pud_t *pudp = pud_offset(pgdp, start);

	do {
		pud_t pud = READ_ONCE(*pudp);
		next = pud_addr_end(addr, end);

		if (pud_none(pud) || pud_sect(pud)) {
			note_page(st, addr, 2, pud_val(pud));
		} else {
			BUG_ON(pud_bad(pud));
			walk_pmd(st, pudp, addr, next);
		}
	} while (pudp++, addr = next, addr != end);
}

static void walk_pgd(struct pg_state *st, struct mm_struct *mm,
		     unsigned long start)
{
	/*unsigned long end = (start < TASK_SIZE_64) ? TASK_SIZE_64 : 0;*/
	unsigned long end = 0;
	unsigned long next, addr = start;
	pgd_t *pgdp = pgd_offset(mm, start);

	do {
		pgd_t pgd = READ_ONCE(*pgdp);
		next = pgd_addr_end(addr, end);

		if (pgd_none(pgd)) {
			note_page(st, addr, 1, pgd_val(pgd));
		} else {
			BUG_ON(pgd_bad(pgd));
			walk_pud(st, pgdp, addr, next);
		}
	} while (pgdp++, addr = next, addr != end);
}

void ptdump_walk_pgd(struct seq_file *m, struct ptdump_info *info)
{
	struct pg_state st = {
		.seq = m,
		.marker = info->markers,
	};

	walk_pgd(&st, info->mm, info->base_addr);

	note_page(&st, 0, 0, 0);
}

static void ptdump_initialize(void)
{
	unsigned i, j;

	for (i = 0; i < ARRAY_SIZE(pg_level); i++)
		if (pg_level[i].bits)
			for (j = 0; j < pg_level[i].num; j++)
				pg_level[i].mask |= pg_level[i].bits[j].mask;
}

static struct ptdump_info kernel_ptdump_info = {
	.mm		= &init_mm,
	.markers	= address_markers,
	.base_addr	= VA_START,
};

/*void ptdump_check_wx(void)
{
	struct pg_state st = {
		.seq = NULL,
		.marker = (struct addr_marker[]) {
			{ 0, NULL},
			{ -1, NULL},
		},
		.check_wx = true,
	};

	walk_pgd(&st, &init_mm, VA_START);
	note_page(&st, 0, 0, 0);
	if (st.wx_pages || st.uxn_pages)
		pr_warn("Checked W+X mappings: FAILED, %lu W+X pages found, %lu non-UXN pages found\n",
			st.wx_pages, st.uxn_pages);
	else
		pr_info("Checked W+X mappings: passed, no W+X pages found\n");
}*/

static int ptdump_init(void)
{
	ptdump_initialize();
	ptdump_debugfs_register(&kernel_ptdump_info, "kernel_page_tables");
	return 0;
}
device_initcall(ptdump_init);
